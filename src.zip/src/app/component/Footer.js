import React from 'react';
import './Footer.css';

function Footer(){

    return(
        <div>
    <div  id="footerDiv">
       
        <h1 id="footerh1"> &#129409; Monalisa   &#129409; </h1>
     </div>
     </div>
    );
}
export default Footer;


